#!/bin/sh
/www/cgi-bin/bgstopwatch.pl >> /tmp/stopwatch.log 2>&1 &
